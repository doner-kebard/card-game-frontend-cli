module Psych
  class Omap < ::Hash
  end
end
